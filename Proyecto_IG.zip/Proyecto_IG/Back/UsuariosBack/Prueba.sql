CREATE TABLE cargos (
    id INT IDENTITY PRIMARY KEY not null,
    codigo VARCHAR(50) not null,
    nombre VARCHAR(100) not null,
    activo BIT not null,
    idUsuarioCreacion INT
);
