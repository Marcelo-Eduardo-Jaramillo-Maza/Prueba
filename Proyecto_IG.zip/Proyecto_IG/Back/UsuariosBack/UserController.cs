﻿using Microsoft.AspNetCore.Mvc;
using UsuariosBack;

namespace UsuariosBack
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserAdminDbContext _DbContext;

        public object EntityState { get; private set; }

        public UserController(UserAdminDbContext DbContext)
        {
            _DbContext = DbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            return await _DbContext.Users.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = await _DbContext.Users.FindAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        [HttpPost]
        public async Task<ActionResult<User>> PostUser(User user)
        {
            _DbContext.Users.Add(user);
            await _DbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUser), new { id = user.Id }, user);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutUser(int id, User user)
        {
            if (id != user.Id)
            {
                return BadRequest();
            }

            _DbContext.Attach(user).State = EntityState.Modified;
            await _DbContext.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var user = await _DbContext.Users.FindAsync(new object[] { id });
            if (user == null)
            {
                return NotFound();
            }

            _DbContext.Users.Remove(user);
            await _DbContext.SaveChangesAsync();

            return NoContent();
        }

}
[ApiController]
[Route("api/departments")]
public class DepartmentController : ControllerBase
{
    private readonly UserAdminDbContext _DbContext;

    public DepartmentController(UserAdminDbContext DbContext)
    {
        _DbContext = DbContext;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Department>>> GetDepartments()
    {
        return await _DbContext.Departments.ToListAsync();
    }

    // Add the rest of the CRUD operations for DepartmentController
}

[ApiController]
[Route("api/positions")]
public class PositionController : ControllerBase
{
    private readonly UserAdminDbContext _DbContext;

    public PositionController(UserAdminDbContext dbContext)
    {
        _DbContext = dbContext;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Position>>> GetPositions()
    {
        return await _DbContext.Positions.ToListAsync();
    }

    // Add the rest of the CRUD operations for PositionController
}
}