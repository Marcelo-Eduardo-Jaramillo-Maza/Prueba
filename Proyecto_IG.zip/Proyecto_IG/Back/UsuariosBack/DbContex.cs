﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace UsuariosBack
{
    public class UserAdminDbContext 
    {
        public UserAdminDbContext(DbContextOptions<UserAdminDbContext> options)
            
            : base (options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Position> Positions { get; set; }

        internal object Attach(User user)
        {
            throw new NotImplementedException();
        }

        internal object Entry(User user)
        {
            throw new NotImplementedException();
        }

        internal Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }

        public class DbSet<T>
        {
            internal Task FindAsync(int id)
            {
                throw new NotImplementedException();
            }

            internal Task FindAsync(object[] objects)
            {
                throw new NotImplementedException();
            }

            internal Task<ActionResult<IEnumerable<User>>> ToListAsync()
            {
                throw new NotImplementedException();
            }
        }
    }

    public class DbContextOptions<T>
    {
    }
}
