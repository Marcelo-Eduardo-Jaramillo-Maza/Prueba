﻿using System.Reflection.Emit;
using UsuariosBack;

namespace UsuariosBack
{
    public class Department
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public bool Active { get; set; }
        public int CreatedByUserId { get; set; }
    }

    public class Position
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public bool Active { get; set; }
        public int CreatedByUserId { get; set; }
    }
}
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    modelBuilder.Entity<Department>().HasData(
        new Department { Id = 1, Code = "TI", Name = "Tecnologías de la Información", Active = true, CreatedByUserId = 1 },
        new Department { Id = 2, Code = "LE", Name = "Legal", Active = true, CreatedByUserId = 1 },
        new Department { Id = 3, Code = "SG", Name = "Seguridad", Active = true, CreatedByUserId = 1 }
    );

    modelBuilder.Entity<Position>().HasData(
        new Position { Id = 1, Code = "AD", Name = "Administrador", Active = true, CreatedByUserId = 1 },
        new Position { Id = 2, Code = "DF", Name = "Desarrollador Frontend", Active = true, CreatedByUserId = 1 },
        new Position { Id = 3, Code = "GA", Name = "Guardia", Active = true, CreatedByUserId = 1 }
    );
}