﻿namespace UsuariosBack
{
    public class User
{
    public User(int id, string username, string firstName, string lastName, string email, int departmentId, int positionId)
    {
        Id = id;
        Username = username;
        FirstName = firstName;
        LastName = lastName;
        Email = email;
        DepartmentId = departmentId;
        PositionId = positionId;
    }

    public int Id { get; set; }
    public string Username { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public int DepartmentId { get; set; }
    public int PositionId { get; set; }
    }
}